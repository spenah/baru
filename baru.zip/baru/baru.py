from linepy import *

from akad.ttypes import *

from datetime import datetime, timedelta

from time import sleep

from bs4 import BeautifulSoup

from humanfriendly import format_timespan, format_size, format_number, format_length

from gtts import gTTS

from threading import Thread

from io import StringIO

from multiprocessing import Pool

from urllib.parse import urlencode

from random import randint

from shutil import copyfile

from youtube_dl import YoutubeDL

import subprocess

import youtube_dl

import humanize

import traceback

import time

import random

import sys

import os

import json

import null

import codecs

import html5lib

import shutil

import glob

import re

import base64

import string

import requests

import six

import ast

import pytz

import wikipedia

import urllib

import urllib.parse

import atexit

import asyncio

import livejson
#=================
baru = LINE("@gmail.com","spenah")
baru.log("Auth Token : " + str(baru.authToken))
baruProfile = baru.getProfile()
baruSettings = baru.getSettings()
baruPoll = OEPoll(baru)
baruMID = baru.profile.mid
bot = [baruMID]
waitOpen = codecs.open("wait.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
#==================
loop = asyncio.get_event_loop()
admin =["u82c436a5d5ac9d15c0acf40400ae8f51","u463dba32483bf1fa9141299c312afe15"]
status = [admin]
#============
with open("temp.json", "r", encoding="utf_8_sig") as f:
	set = json.loads(f.read())
	set.update(settings)
	settings = set
with open("wait.json", "r", encoding="utf_8_sig") as f:
	waits = json.loads(f.read())
	waits.update(wait)
	wait = waits
def logError(text):
	baru.log("ERROR 404 !\n" + str(text))
	tz = pytz.timezone("Asia/Jakarta")
	timeNow = datetime.now(tz=tz)
	timeHours = datetime.strftime(timeNow,"(%H:%M)")
	day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
	hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
	bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
	inihari = datetime.now(tz=tz)
	hr = inihari.strftime('%A')
	bln = inihari.strftime('%m')
	for i in range(len(day)):
		if hr == day[i]: hasil = hari[i]
	for k in range(0, len(bulan)):
		if bln == str(k): bln = bulan[k-1]
	time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
	with open("errorLog.txt","a") as error:
		error.write("\n[%s] %s" % (str(time), text))
def restartBot():
	python = sys.executable
	os.execl(python,python,*sys.argv)
def allow_liff():
	url = 'https://access.line.me/dialog/api/permissions'
	data = {
	    'on': [
	        'P',
	        'CM'
	    ],
	    'off': []
	}
	headers = {
	    'X-Line-Access': baru.authToken,
	    'X-Line-Application': baru.server.APP_NAME,
	    'X-Line-ChannelId': '1653391722',
	    'Content-Type': 'application/json'
	}
	requests.post(url, json=data, headers=headers)
def sendTemplate(group, data):
	allow_liff()
	xyz = LiffChatContext(group)
	xyzz = LiffContext(chat=xyz)
	view = LiffViewRequest('1653391722-QN5aXrrz', xyzz)
	token = baru.liff.issueLiffView(view)
	url = 'https://api.line.me/message/v3/share'
	headers = {
	    'Content-Type': 'application/json',
	    'Authorization': 'Bearer %s' % token.accessToken
	}
	data = {"messages":[data]}
	requests.post(url, headers=headers, data=json.dumps(data))
def sendTemplate(to, data):
	allow_liff()
	xyz = LiffChatContext(to)
	xyzz = LiffContext(chat=xyz)
	view = LiffViewRequest('1653391722-QN5aXrrz', xyzz)
	token = baru.liff.issueLiffView(view)
	url = 'https://api.line.me/message/v3/share'
	headers = {
	    'Content-Type': 'application/json',
	    'Authorization': 'Bearer %s' % token.accessToken
	}
	data = {"messages":[data]}
	requests.post(url, headers=headers, data=json.dumps(data))
def sendContol(to, penahhh):
	data = {"type": "image","originalContentUrl": penahhh,"previewImageUrl": penahhh,"sentBy": {"label": foname["squad"],"iconUrl": "https://obs.line-scdn.net/{}".format(spen.getContact("ub04637c2c85095ab5e2f5ed3756223c9").pictureStatus),"linkUrl": "https://line.me/ti/p/~assisten3"}}
	sendTemplate(to, data)
def backupData():
	try:
		backup = settings
		f = codecs.open('temp.json','w','utf-8')
		json.dump(backup,f,sort_keys=True,indent=4,ensure_ascii=False)
		backup = wait
		f = codecs.open('wait.json','w','utf-8')
		json.dump(backup,f,sort_keys=True,indent=4,ensure_ascii=False)
		backup = status
		f = codecs.open('status.json','w','utf-8')
		json.dump(backup,f,sort_keys=True,indent=4,ensure_ascii=False)
		return True
	except Exception as error:
		logError(error)
		return False
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": foname["squad"],
            "iconUrl": "https://i.ibb.co/vPdsxjW/1610490636382.jpg",
            "linkUrl": "line://app/1571191887-d6rJnOxJ/?type=text&text=Gua%20Tolol%20Banget"
        }
    }
    sendTemplate(to, data)
#====================
pengaturan = {
    "joinTicket": True,
    "autoJoin": True,
}
nissa = {
    "addTikel2": {
        "name": "",
        "status": False
        },
}
tes = {
    "Message": {},
    "msg": {},
}
foname = {
    "squad": "Kalera Team♪",
}
#====================
async def anuxkontol(op):
	try:
		if op.type == OpType.END_OF_OPERATION:
			return
		if op.type == 5:
			baru.sendMessage(op.param1, "Hai")
		if op.type == 19 or op.type == 133:
			if op.param3 in admin:
				if op.param2 not in admin:
					try:
						baru.findAndAddContactsByMid(op.param3)
						baru.kickoutFromGroup(op.param1,[op.param2])
						baru.inviteIntoGroup(op.param1,[op.param3])
						baru.acceptGroupInvitation(op.param1)
					except:pass
		if op.type == 13 or op.type == 124:
			if op.param2 in admin:
				baru.acceptGroupInvitation(op.param1)
			else:
				penai = baru.getCompactGroup(op.param1)
				if len(penai.members) <= 20:
					baru.acceptGroupInvitation(op.param1)
					baru.sendMention(op.param1, "harus 20 mem bro @!"," ",[op.param2])
					baru.leaveGroup(op.param1)
				else:
					baru.acceptGroupInvitation(op.param1)
		if op.type == 26 or op.type == 25:
			msg = op.message
			text = msg.text
			reply = msg.id
			receiver = msg.to
			sender = msg._from
			to = msg.to
			isValid = True
			if isValid != False:
				if msg.toType == 0 and sender != baruMID: to = sender
				else: to = receiver
				if msg.contentType == 0:
					if text is None:pass
					else:
					   spenah = msg.text.lower()
					for kalera in spenah.split(" & "):
						if kalera == "yo":
							baru.sendMessage(to, None, contentMetadata={"STKID":"406","STKPKGID":"1","STKVER":"100"}, contentType=7)
						elif kalera == "help":
							if sender in admin:
								sendFooter(to, "۝ Help Command ۝\n\n1.Addtext 「text/ text」\n2.DelText 「Text」\n3.List Text\n4.ChatOwner\n5.Grouplist\n6.!exc\n7.Resbot")
							else:
								sendFooter(to, "۝ Help Command ۝\n\n1.Addtext 「text/ text」\n2.DelText 「Text」\n3.List Text\n4.ChatOwner ")
						elif kalera == "resbot":
							sendFooter(to, "Rebooting\nWait For 3 Seconds")
							time.sleep(3)
							sendFooter(to, "Done")
							restartBot()
						elif kalera.startswith("addtext "):
							sep = text.split(" ")
							apl = text.replace(sep[0] + " ","")
							sam = apl.split("/")
							chat1 = sam[0]
							chat2 = sam[1]
							apk = ""+chat1
							tes["Message"][apk] = chat2
							tes["msg"] = chat1
							anu = tes["msg"]+'.'
							baru.sendReplyMessage(msg.id,to,"Command %s Created."%chat1)
							tes["msg"] = {}
							backupData()
						if text in tes["Message"]:
							baru.sendReplyMessage(msg.id, to, tes["Message"][msg.text])                          
						elif kalera == "list text":
							backupData()
							if tes["Message"] == {}:
								baru.sendReplyMessage(msg.id,to,"You Don't Have Text Message")
							else:
								mc = ""
								jml = 1
								for listword in tes["Message"]:
									mc += "\n"+str(jml)+". "+listword+""
									jml += 1
								baru.generateReplyMessage(msg.id)
								baru.sendReplyMessage(msg.id, to, "List Text :\n"+str(mc))
						elif kalera.startswith("deltext "):
							sep = text.split(" ")
							xres = text.replace(sep[0] + " ","")
							tetx = text.replace(sep[0] + " ","")
							if xres in tes["Message"]:
								del tes["Message"][xres]                                        
								baru.sendReplyMessage(msg.id,to,"Command %s Has Been Deleted."%tetx)
							else:
								baru.sendReplyMessage(msg.id,to,"Command %s Does not Exist."%tetx)
						elif kalera == "tagall":
							try:
								group = baru.getGroup(to)
								member = [a.mid for a in group.members]
								member.remove(baru.profile.mid)
								baru.datamention(to,"「Mention Members」",member)
							except Exception as e:
								sendFooter(to, str(e))
						elif kalera.startswith("openqr "):
							if sender in admin:
								sep = text.split(" ")
								number = text.replace(sep[0] + " ","")
								groups = baru.getGroupIdsJoined()
								group = groups[int(number)-1]
								G = baru.getGroup(group)
								G.preventedJoinByTicket = False
								baru.updateGroup(G)
								url = baru.reissueGroupTicket(group)
								ticket = 'Sukses Remoted Commands\nOpen qr in groups {}\nlink: https://line.me/R/ti/g/{}'.format(G.name,url)
								baru.sendReplyMessage(msg.id,to,ticket)
						elif kalera == "grouplist":
							if sender in admin:
								gid = baru.getGroupIdsJoined()
								sd = baru.getGroups(gid)
								ret = "「 Group List 」\n"
								no = 0
								total = len(gid)
								cd = "\n\nTotal groups : {} ".format(total)
								for G in sd:
									member = len(G.members)
									no += 1
									ret += "\n{}. {} ({})".format(no, G.name[0:50], member)
								ret += cd
								k = len(ret)//10000
								for aa in range(k+1):
									baru.generateReplyMessage(msg.id)
									baru.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
						elif "/ti/g/" in msg.text.lower():
							if pengaturan["joinTicket"] == True:
								link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
								links = link_re.findall(text)
								n_links = []
								for l in links:
									if l not in n_links:
										n_links.append(l)
								for ticket_id in n_links:
									group = baru.findGroupByTicket(ticket_id)
									baru.acceptGroupInvitationByTicket(group.id,ticket_id)
									sendFooter(to, "%s" % str(group.name))
#==========
								
	except Exception as e:
		e = traceback.format_exc()
		if "EOFError" in e:
			backup_data()
			print("[+] NOTIFICATION : EOF ERROR OCCURRED AND WAIT FOR 10 MINUTES TO RE RUN")
			time.sleep(600)
			python3 = sys.executable
			os.execl(python3, python3, *sys.argv)
		else:
			traceback.print_exc()
def run():
	while True:
		try:
			ops = baruPoll.singleTrace(count=50)
			if ops != None:
				for op in ops:
					loop.run_until_complete(anuxkontol(op))
					baruPoll.setRevision(op.revision)
		except TalkException as error:
			traceback.print_tb(error.__traceback__)
if __name__ == "__main__":
	print("success")
	run()
